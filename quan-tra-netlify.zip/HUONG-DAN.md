# Cài đặt (làm một lần)
1. Đưa toàn bộ thư mục này lên một repo GitHub, rồi trên Netlify chọn Add new site > Import from Git.
2. Site configuration > Environment variables, thêm 3 biến:
   - TELEGRAM_BOT_TOKEN : mã BotFather đưa
   - TELEGRAM_CHAT_ID : số id của nhóm Telegram (thường là số âm)
   - ADMIN_PASSWORD : mật khẩu quản lý do bạn tự đặt
3. Deploy lại site. Mở link kèm #admin phía sau (ví dụ ten-quan.netlify.app/#admin) rồi bấm nút Quản lý.
